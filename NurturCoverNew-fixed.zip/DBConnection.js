// DBConnection.js
const sql = require('mssql');
require('dotenv').config();

const dbConfig = {
  user: process.env.DB_USER || 'NurturCover_shoulderit',
  password: process.env.DB_PASSWORD || 'REDACTED',
  server: process.env.DB_SERVER || 'localhost',
  database: process.env.DB_NAME || 'NurturCover_shoulderit',
  options: {
    encrypt: false,
    trustServerCertificate: true,
    instanceName: process.env.DB_INSTANCE || 'SQLEXPRESS01'
  },
  pool: {
    max: 10,
    min: 0,
    idleTimeoutMillis: 30000
  }
};

const pool = new sql.ConnectionPool(dbConfig);

async function connectDB() {
  if (!pool.connected && !pool.connecting) {
    await pool.connect();
  }
  return pool;
}

module.exports = { sql, pool, connectDB };
